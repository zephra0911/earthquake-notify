import logging
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

TABLE_NAME    = "EarthquakeNotify"
PARTITION_KEY = "quake"
STATUS_ALERTED  = "ALERTED"
STATUS_DETAILED = "DETAILED"

def get_table_client(connection_string: str):
    from azure.data.tables import TableServiceClient
    service = TableServiceClient.from_connection_string(connection_string)
    service.create_table_if_not_exists(TABLE_NAME)
    logger.info(f"Storage Table 接続完了: {TABLE_NAME}")
    return service.get_table_client(TABLE_NAME)

def get_status(client, event_id: str) -> Optional[str]:
    try:
        entity = client.get_entity(
            partition_key=PARTITION_KEY,
            row_key=_sanitize_key(event_id),
        )
        return entity.get("status")
    except Exception:
        return None

def is_alerted(client, event_id: str) -> bool:
    return get_status(client, event_id) in (STATUS_ALERTED, STATUS_DETAILED)

def is_detailed(client, event_id: str) -> bool:
    return get_status(client, event_id) == STATUS_DETAILED

def mark_alerted(client, event_id: str) -> bool:
    entity = {
        "PartitionKey": PARTITION_KEY,
        "RowKey":       _sanitize_key(event_id),
        "status":       STATUS_ALERTED,
        "alerted_at":   _now_iso(),
        "detailed_at":  "",
    }
    return _upsert(client, entity, "速報済みマーク")

def mark_detailed(client, event_id: str) -> bool:
    try:
        entity = client.get_entity(
            partition_key=PARTITION_KEY,
            row_key=_sanitize_key(event_id),
        )
        entity["status"]      = STATUS_DETAILED
        entity["detailed_at"] = _now_iso()
        return _upsert(client, entity, "続報済みマーク")
    except Exception:
        entity = {
            "PartitionKey": PARTITION_KEY,
            "RowKey":       _sanitize_key(event_id),
            "status":       STATUS_DETAILED,
            "alerted_at":   "",
            "detailed_at":  _now_iso(),
        }
        return _upsert(client, entity, "続報済みマーク（新規）")

def _upsert(client, entity: dict, label: str) -> bool:
    try:
        client.upsert_entity(entity)
        logger.info(f"{label}完了: {entity['RowKey']}")
        return True
    except Exception as e:
        logger.error(f"{label}失敗: {e}")
        return False

def _sanitize_key(event_id: str) -> str:
    if "/" in event_id:
        return event_id.rstrip("/").split("/")[-1][:254]
    forbidden = set('/\\#?')
    return "".join(c for c in event_id if c not in forbidden)[:254]

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()